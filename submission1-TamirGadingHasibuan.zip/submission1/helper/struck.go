// helper/struck.go

package helper

// Teman represents data of a friend
type Teman struct {
    Nama     string
    Alamat   string
    Pekerjaan string
    Alasan   string
}
